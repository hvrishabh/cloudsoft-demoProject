(function ($, window, Drupal) {
  Drupal.behaviors.cloudsoft = {
    attach: function (context, settings) {

      $(".features_class").click(function (e) {
        items = document.getElementsByClassName("para");
        for (var i = 0; i < items.length; i++) {
          items[i].classList.add("d-none");
        }
        $(e.target.hash).toggleClass("d-none");
      });



    },
  };
})(jQuery, window, Drupal);
